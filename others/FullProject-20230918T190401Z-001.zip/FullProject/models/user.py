from models.base_model import BaseModel


class User(BaseModel):
    """User class that inherits from BaseModel."""
    email = "test@email.com"
    password = "12345"
    first_name = "John"
    last_name = "Doe"
