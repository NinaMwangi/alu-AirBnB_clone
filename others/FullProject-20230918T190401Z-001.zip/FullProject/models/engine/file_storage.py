import json
import os


class FileStorage:
    """Create the FileStorage class in models/engine/file_storage.py:"""

    __file_path = "file.json"
    __objects = {}

    def all(self):
        return self.__objects

    def new(self, obj):
        key = "{}.{}".format(obj.__class__.__name__, obj.id)
        self.__objects[key] = obj

    def save(self):
        obj_dict = {}
        for key, obj in self.__objects.items():
            obj_dict[key] = obj.to_dict()
        with open(self.__file_path, 'w', encoding='utf-8') as file:
            json.dump(obj_dict, file)

    def reload(self):
        if os.path.isfile(self.__file_path):
            with open(self.__file_path, 'r', encoding='utf-8') as file:
                obj_dict = json.load(file)
                for key, value in obj_dict.items():
                    if "__class__" in value and value["__class__"] in globals():
                        class_name = value["__class__"]
                        obj_id = value["id"]
                        # Remove the '__class__' attribute
                        del value["__class__"]
                        self.__objects[key] = globals()[class_name](**value)
                    else:
                        print(
                            f"Warning: Unknown class or missing '__class__' attribute in JSON data.")
