#!/usr/bin/python3
"""
This module contains the entry point of the command interpreter.
"""

import cmd
import sys
import models
from models.base_model import BaseModel
from models.state import State
from models.city import City
from models.amenity import Amenity
from models.place import Place
from models.review import Review
from models.user import User


class HBNBCommand(cmd.Cmd):
    prompt = '(hbnb) '
    classes = {
        'BaseModel': BaseModel,
        'User': User,
        'State': State,
        'City': City,
        'Amenity': Amenity,
        'Place': Place,
        'Review': Review,
    }

    def do_quit(self, args):
        """Quit command to exit the program"""
        sys.exit()

    def do_EOF(self, args):
        """EOF command to exit the program"""
        sys.exit()

    def emptyline(self):
        """Do nothing on empty input line"""
        pass

    def do_create(self, args):
        """Create a new instance of BaseModel"""
        from models.base_model import BaseModel
        from models import storage

        if not args:
            print("** class name missing **")
        elif args not in self.classes:
            print("** class doesn't exist **")
        else:
            new_instance = self.classes[args]()
            new_instance.save()
            models.storage.new(new_instance)
            models.storage.save()
            print(new_instance.id)

    def do_show(self, args):
        """Prints the string representation of an instance"""
        import models
        args = args.split()
        if len(args) == 0:
            print("** class name missing **")
        elif args[0] not in self.classes:
            print("** class doesn't exist **")
        elif len(args) < 2:
            print("** instance id missing **")
        else:
            key = args[0] + "." + args[1]
            objects = models.storage.all()
            if key not in objects:
                print("** no instance found **")
            else:
                print(objects[key])

    def do_destroy(self, args):
        """Deletes an instance based on the class name and id"""
        args = args.split()
        if len(args) == 0:
            print("** class name missing **")
        elif args[0] not in self.classes:
            print("** class doesn't exist **")
        elif len(args) < 2:
            print("** instance id missing **")
        else:
            key = args[0] + "." + args[1]
            objects = models.storage.all()
            if key not in objects:
                print("** no instance found **")
            else:
                del objects[key]
                models.storage.save()

    def do_all(self, args):
        """Prints all string representation of all instances"""
        args = args.split()
        if len(args) == 0:
            objects = models.storage.all()
            obj_list = []
            for key in objects:
                obj_list.append(str(objects[key]))
            print(obj_list)
        elif args[0] not in self.classes:
            print("** class doesn't exist **")
        else:
            objects = models.storage.all(self.classes[args[0]])
            obj_list = []
            for key in objects:
                obj_list.append(str(objects[key]))
            print(obj_list)

    def do_update(self, args):
        """Updates an instance based on the class name and id"""
        args = args.split()
        if len(args) == 0:
            print("** class name missing **")
        elif args[0] not in self.classes:
            print("** class doesn't exist **")
        elif len(args) < 2:
            print("** instance id missing **")
        else:
            key = args[0] + "." + args[1]
            objects = models.storage.all()
            if key not in objects:
                print("** no instance found **")
            elif len(args) < 3:
                print("** attribute name missing **")
            elif len(args) < 4:
                print("** value missing **")
            else:
                instance = objects[key]
                attr_name = args[2]
                attr_value = args[3]
                if hasattr(instance, attr_name):
                    attr_type = type(getattr(instance, attr_name))
                    setattr(instance, attr_name, attr_type(attr_value))
                    instance.save()
                else:
                    print("** attribute doesn't exist **")


if __name__ == '__main__':
    HBNBCommand().cmdloop()
